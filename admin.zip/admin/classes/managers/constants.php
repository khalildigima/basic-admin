<?php

// User types
define("ADMIN", 1);
define("CUSTOMER", 2);
define("RETAILER", 3);
define("EMPLOYEE", 4);

define("SUCCESS", "success");
define("FAILURE", "failure");

// permissions
define("USER_PERM", 1);
define("PRODUCT_PERM", 2);
define("ORDER_PERM", 3);